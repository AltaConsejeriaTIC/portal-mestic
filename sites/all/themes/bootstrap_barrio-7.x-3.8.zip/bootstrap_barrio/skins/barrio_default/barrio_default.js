jQuery(document).ready(function() {

  jQuery('.barrio-modal').after('<section class="sideral-corner after"><a href="#block-block-1" role="button" class="btn" data-toggle="modal">Launch demo modal</a></section>');

});
